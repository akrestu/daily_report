<?php

namespace App\Livewire\DailyReports;

use App\Models\DailyReport;
use App\Models\Department;
use App\Models\JobSite;
use App\Models\Section;
use App\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use Illuminate\Support\Facades\Log;

class DailyReportForm extends Component
{
    use WithFileUploads;
    
    // Form fields
    public $reportId;
    public $jobName;
    public $departmentId;
    public $jobSiteId;
    public $sectionId;
    public $reportDate;
    public $dueDate;
    public $jobPic;
    public $description;
    public $remark;
    public $status = 'pending';
    public $attachment;
    public $attachment_2;
    public $attachment_3;

    // For editing
    public $existingAttachment;
    public $existingAttachmentName;
    public $existingAttachment2;
    public $existingAttachmentName2;
    public $existingAttachment3;
    public $existingAttachmentName3;
    public $isEditMode = false;
    
    // For multiple reports form
    public $showMultipleForm = false;
    public $multipleReports = [];
    
    // For validation
    public $eligiblePics;
    
    // Loading state
    public $isSubmitting = false;
    
    // Validation rules
    protected function rules()
    {
        $attachmentRules = 'nullable|file|max:5120|mimes:jpeg,png,jpg,gif,svg,pdf,doc,docx,xls,xlsx';

        return [
            'jobName' => 'required|string|max:255',
            'departmentId' => 'required|exists:departments,id',
            'jobSiteId' => 'nullable|exists:job_sites,id',
            'sectionId' => 'nullable|exists:sections,id',
            'reportDate' => 'required|date',
            'dueDate' => 'required|date|after_or_equal:reportDate',
            'jobPic' => 'required|exists:users,id',
            'description' => 'required|string',
            'remark' => 'nullable|string',
            'status' => 'required|in:pending,in_progress,completed',
            'attachment' => $attachmentRules,
            'attachment_2' => $attachmentRules,
            'attachment_3' => $attachmentRules,
        ];
    }
    
    public function __construct()
    {
        parent::__construct();
        $this->eligiblePics = collect([]);
    }
    
    public function mount($dailyReport = null)
    {
        // Set today as default for report date
        $this->reportDate = date('Y-m-d');
        
        // Set default department to user's department
        $user = Auth::user();
        $this->departmentId = $user->department_id;
        
        // Load eligible PICs for the user's department
        $this->loadEligiblePics();
        
        // If editing existing report
        if ($dailyReport) {
            $this->isEditMode = true;
            $this->reportId = $dailyReport->id;
            $this->jobName = $dailyReport->job_name;
            $this->departmentId = $dailyReport->department_id;
            $this->jobSiteId = $dailyReport->job_site_id;
            $this->sectionId = $dailyReport->section_id;
            $this->reportDate = $dailyReport->report_date->format('Y-m-d');
            $this->dueDate = $dailyReport->due_date->format('Y-m-d');
            $this->jobPic = $dailyReport->job_pic;
            $this->description = $dailyReport->description;
            $this->remark = $dailyReport->remark;
            $this->status = $dailyReport->status;
            
            if ($dailyReport->attachment_path) {
                $this->existingAttachment = $dailyReport->attachment_path;
                $this->existingAttachmentName = $dailyReport->attachment_original_name;
            }
            if ($dailyReport->attachment_path_2) {
                $this->existingAttachment2 = $dailyReport->attachment_path_2;
                $this->existingAttachmentName2 = $dailyReport->attachment_original_name_2;
            }
            if ($dailyReport->attachment_path_3) {
                $this->existingAttachment3 = $dailyReport->attachment_path_3;
                $this->existingAttachmentName3 = $dailyReport->attachment_original_name_3;
            }
            
            // Load eligible PICs including current PIC
            $this->loadEligiblePics($this->jobPic);
        }
    }
    
    public function updatedDepartmentId()
    {
        $this->loadEligiblePics();
        $this->jobPic = ''; // Reset PIC when department changes
        $this->sectionId = ''; // Reset Section when department changes
    }
    
    private function loadEligiblePics($currentPicId = null)
    {
        /** @var User $user */
        $user = Auth::user();

        // Get eligible role slugs based on current user's role
        $eligibleRoleSlugs = $user->getEligiblePicRoles();

        if (empty($eligibleRoleSlugs)) {
            $this->eligiblePics = collect([]);
            return;
        }

        // Get role IDs for eligible slugs
        $eligibleRoleIds = Role::whereIn('slug', $eligibleRoleSlugs)->pluck('id');

        // Get users with eligible roles from the SAME DEPARTMENT, excluding self (no self-PIC)
        $query = User::whereIn('role_id', $eligibleRoleIds)
            ->where('id', '!=', $user->id)
            ->where('department_id', $user->department_id) // Filter by same department
            ->get();

        $this->eligiblePics = $query;

        // If we have a current PIC and they're not in the eligible list, add them
        if ($currentPicId) {
            $currentPic = User::find($currentPicId);
            if ($currentPic && !$this->eligiblePics->contains('id', $currentPicId)) {
                $this->eligiblePics->push($currentPic);
            }
        }
    }
    
    /**
     * Process and store file attachment
     */
    private function processAttachment($file, $oldAttachmentPath = null)
    {
        // Generate a secure filename
        $originalName = $file->getClientOriginalName();
        $extension = $file->getClientOriginalExtension();
        $filename = uniqid('attachment_', true) . '_' . time() . '.' . $extension;
        $path = 'attachments/' . $filename;
        
        // Create attachments directory if it doesn't exist
        if (!Storage::disk('public')->exists('attachments')) {
            Storage::disk('public')->makeDirectory('attachments');
        }
        
        // Delete old file if exists
        if ($oldAttachmentPath) {
            Storage::disk('public')->delete($oldAttachmentPath);
        }
        
        // Check if it's an image and process if GD extension is available
        if (in_array(strtolower($extension), ['jpg', 'jpeg', 'png', 'gif'])) {
            try {
                // Check if GD extension is available
                if (!extension_loaded('gd')) {
                    throw new \Exception('GD extension not available');
                }
                
                // Create image manager with GD driver
                $manager = new ImageManager(Driver::class);
                
                // Load and compress image
                $image = $manager->read($file->getRealPath());
                
                // Resize if width or height is greater than 1920px while maintaining aspect ratio
                $image->scaleDown(1920, 1920);
                
                // Save compressed image to public disk with higher compression (60% quality instead of 80%)
                Storage::disk('public')->put($path, $image->toJpeg(60));
            } catch (\Exception $e) {
                // Fallback: Store image without processing if GD is not available
                Log::warning('Image processing failed, storing without compression: ' . $e->getMessage());
                Storage::disk('public')->putFileAs('attachments', $file, $filename);
            }
        } else {
            // For non-image files, store as is in public disk under attachments directory
            Storage::disk('public')->putFileAs('attachments', $file, $filename);
        }
        
        return [
            'path' => $path,
            'originalName' => $originalName
        ];
    }
    
    public function save()
    {
        $this->isSubmitting = true;

        // Validate the form data
        $this->validate();

        // Validate no self-PIC
        if ($this->jobPic == Auth::id()) {
            session()->flash('error', 'You cannot assign yourself as PIC.');
            $this->isSubmitting = false;
            return;
        }

        // Validate PIC is in eligible list
        if (!$this->eligiblePics->contains('id', $this->jobPic)) {
            session()->flash('error', 'The selected PIC is not valid based on your role level.');
            $this->isSubmitting = false;
            return;
        }

        try {
            $attachmentPath = $this->existingAttachment;
            $originalName = $this->existingAttachmentName;
            $attachmentPath2 = $this->existingAttachment2;
            $originalName2 = $this->existingAttachmentName2;
            $attachmentPath3 = $this->existingAttachment3;
            $originalName3 = $this->existingAttachmentName3;

            // Process the first attachment if provided
            if ($this->attachment) {
                $attachmentData = $this->processAttachment($this->attachment, $this->existingAttachment);
                $attachmentPath = $attachmentData['path'];
                $originalName = $attachmentData['originalName'];
            }

            // Process the second attachment if provided
            if ($this->attachment_2) {
                $attachmentData2 = $this->processAttachment($this->attachment_2, $this->existingAttachment2);
                $attachmentPath2 = $attachmentData2['path'];
                $originalName2 = $attachmentData2['originalName'];
            }

            // Process the third attachment if provided
            if ($this->attachment_3) {
                $attachmentData3 = $this->processAttachment($this->attachment_3, $this->existingAttachment3);
                $attachmentPath3 = $attachmentData3['path'];
                $originalName3 = $attachmentData3['originalName'];
            }

            $data = [
                'user_id' => Auth::id(),
                'job_name' => $this->jobName,
                'department_id' => $this->departmentId,
                'job_site_id' => $this->jobSiteId,
                'section_id' => $this->sectionId,
                'job_pic' => $this->jobPic,
                'report_date' => $this->reportDate,
                'due_date' => $this->dueDate,
                'description' => $this->description,
                'remark' => $this->remark,
                'status' => $this->status,
                'attachment_path' => $attachmentPath,
                'attachment_original_name' => $originalName,
                'attachment_path_2' => $attachmentPath2,
                'attachment_original_name_2' => $originalName2,
                'attachment_path_3' => $attachmentPath3,
                'attachment_original_name_3' => $originalName3,
            ];
            
            if ($this->isEditMode) {
                // Update existing report
                $report = DailyReport::findOrFail($this->reportId);
                $report->update($data);
                $message = 'Daily report updated successfully.';
            } else {
                // Create new report
                DailyReport::create($data);
                $message = 'Daily report created successfully.';
            }
            
            // Show success message and redirect
            session()->flash('success', $message);
            $this->redirect(route('daily-reports.index'));
        } catch (\Exception $e) {
            // Delete uploaded file if exists and there was an error
            if (isset($attachmentPath) && $attachmentPath !== $this->existingAttachment && Storage::disk('public')->exists($attachmentPath)) {
                Storage::disk('public')->delete($attachmentPath);
            }
            
            session()->flash('error', 'Error: ' . $e->getMessage());
        }
        
        $this->isSubmitting = false;
    }
    
    public function render()
    {
        $departments = Department::all();
        $jobSites = JobSite::where('is_active', true)->orderBy('name')->get();

        // Get sections for current department
        $sections = collect([]);
        if ($this->departmentId) {
            $sections = Section::where('department_id', $this->departmentId)
                ->where('is_active', true)
                ->orderBy('name')
                ->get();
        }

        return view('livewire.daily-reports.daily-report-form', [
            'departments' => $departments,
            'jobSites' => $jobSites,
            'sections' => $sections,
            'pics' => $this->eligiblePics,
            'dailyReport' => $this->isEditMode ? DailyReport::find($this->reportId) : null,
        ]);
    }
    
    // Methods for multiple reports
    public function addReport()
    {
        $this->multipleReports[] = [
            'job_name' => '',
            'description' => '',
            'due_date' => date('Y-m-d', strtotime('+7 days')),
        ];
    }
    
    public function removeReport($index)
    {
        unset($this->multipleReports[$index]);
        $this->multipleReports = array_values($this->multipleReports);
    }
}
